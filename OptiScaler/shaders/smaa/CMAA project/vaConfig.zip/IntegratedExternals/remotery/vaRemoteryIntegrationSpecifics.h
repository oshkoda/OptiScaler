// included by all remotery .c files but no other engine files - used to disable warnings or similar

#pragma once

#pragma warning ( disable : 4100 )

