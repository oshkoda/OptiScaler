#pragma once

#include "IntegratedExternals\tinyxml2\tinyxml2.h"

namespace VertexAsylum
{
}