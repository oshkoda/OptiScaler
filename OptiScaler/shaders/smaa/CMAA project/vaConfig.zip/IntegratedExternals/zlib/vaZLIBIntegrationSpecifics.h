// included by all bullet .cpp files but no other engine files - used to disable warnings or similar

#pragma once

#pragma warning ( disable : 4702 4457 4458 4244 4706 4463 4189 4505 4127 4100 4456 4459 4245 4701 4267 4389 4714 4315 4131 4996 )

